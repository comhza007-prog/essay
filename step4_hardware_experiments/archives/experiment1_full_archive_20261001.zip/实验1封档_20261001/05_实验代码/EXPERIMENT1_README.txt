Experiment 1 firmware (no-load symmetric low-speed reciprocation)
================================================================

Firmware behavior after reset:
1. Wait 1.5 s and wait until both motor feedback frames are present.
2. Capture current positions as zero.
3. Keep current command at zero for 3 s (arming window).
4. Run exactly one 12 s sequence:
   0-2 s hold at zero
   2-5 s move forward with a fifth-order smooth reference
   5-7 s hold at 0.05 m
   7-10 s return with a fifth-order smooth reference
   10-12 s hold at zero
5. Command zero current forever; reset the board for the next run.

First-run limits:
- stroke: 0.05 m
- motor speed setpoint: +/-300 rpm
- current command: +/-2000 raw units
- CAN timeout: 50 ms
- temperature trip: 80 C
- synchronization error trip: 5 mm
- travel trip: 70 mm

Before running:
- Verify Task/experiment1_config.h: EXP1_DRIVE_RADIUS_M is the actual effective
  drive radius. The supplied value is 0.030 m.
- Lift/unload the mechanism for the first direction check if possible.
- Confirm both sides move the same physical direction. If not, stop power.
- Use a physical power-cut emergency stop. Software protection is not an E-stop.

VOFA+ setup:
- USART6, 115200 baud, JustFloat protocol, 22 channels, approximately 100 Hz.
- Record/export all channels. Channel order is documented in Task/vofa_task.c.
- One formal file per reset/run. Keep at least 5 valid runs.

Fault flags (channel 21, additive bit mask):
1 left CAN timeout; 2 right CAN timeout; 4 over-temperature;
8 synchronization error; 16 over-travel; 32 user/debug abort.

Diagnostic behavior:
- Channel 0 is system uptime and must rise immediately after boot.
- If motor feedback is absent for 3 s, phase becomes 7 and channel 21 is:
  1 = left CAN missing, 2 = right CAN missing, 3 = both missing.

