from pathlib import Path
import json
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont


RAW_DIR = Path(r"C:\Users\ele\Desktop\lunwen\第一次实验")
OUT_DIR = Path(r"C:\Users\ele\Desktop\lunwen\起重机\output\experiment1_archive_staging")
CLEAN_DIR = OUT_DIR / "02_处理后数据"
FIG_DIR = OUT_DIR / "04_论文图"
SUMMARY_DIR = OUT_DIR / "03_统计汇总"

CHANNELS = [f"I{i}" for i in range(22)]
RENAMED = {
    "I0": "uptime_s",
    "I1": "sample_seq",
    "I2": "phase",
    "I3": "reference_m",
    "I4": "pos_left_m",
    "I5": "pos_right_m",
    "I6": "mean_pos_m",
    "I7": "sync_error_mm",
    "I8": "vel_left_mps",
    "I9": "vel_right_mps",
    "I10": "cmd_left_raw",
    "I11": "cmd_right_raw",
    "I12": "feedback_current_left_raw",
    "I13": "feedback_current_right_raw",
    "I14": "sat_left",
    "I15": "sat_right",
    "I16": "temp_left_C",
    "I17": "temp_right_C",
    "I18": "battery_V",
    "I19": "can_age_left_ms",
    "I20": "can_age_right_ms",
    "I21": "fault_flags",
}


def stable_segments(df: pd.DataFrame):
    t = df.I0.to_numpy(float)
    seq = df.I1.to_numpy(float)
    phase = df.I2.to_numpy(float)
    pair_ok = (
        (np.diff(seq) == 1)
        & (np.diff(t) >= 0.008)
        & (np.diff(t) <= 0.020)
        & np.isfinite(phase[1:])
        & (phase[1:] >= 0)
        & (phase[1:] <= 7)
        & (np.abs(phase[1:] - np.round(phase[1:])) < 1e-6)
    )
    padded = np.r_[False, pair_ok, False]
    starts = np.flatnonzero(~padded[:-1] & padded[1:])
    ends = np.flatnonzero(padded[:-1] & ~padded[1:])
    out = []
    for start, end in zip(starts, ends):
        start = int(start)
        end = int(end)
        if end - start + 1 < 100:
            continue
        x = df.iloc[start : end + 1]
        phases = set(x.I2.round().astype(int))
        out.append((start, end, phases))
    return out


def extract_latest_complete(path: Path):
    df = pd.read_csv(path)
    if list(df.columns) != CHANNELS:
        raise ValueError(f"{path.name} columns do not match I0..I21")
    complete = [s for s in stable_segments(df) if set(range(1, 7)).issubset(s[2])]
    if not complete:
        raise ValueError(f"{path.name} has no complete phase 1..6 run")
    start, end, _ = complete[-1]
    segment = df.iloc[start : end + 1].copy().reset_index(drop=True)
    phase = segment.I2.round().astype(int)
    phase1_idx = int(np.flatnonzero((phase == 1).to_numpy())[0])
    phase6_idx = int(np.flatnonzero((phase == 6).to_numpy())[0])
    t0 = float(segment.I0.iloc[phase1_idx])
    end_time = float(segment.I0.iloc[phase6_idx]) + 2.0
    clean = segment[(segment.index >= phase1_idx) & (segment.I0 <= end_time)].copy()
    clean.insert(0, "time_rel_s", clean.I0 - t0)
    clean = clean.rename(columns=RENAMED)
    integer_cols = ["sample_seq", "phase", "sat_left", "sat_right", "temp_left_C", "temp_right_C", "can_age_left_ms", "can_age_right_ms", "fault_flags"]
    for col in integer_cols:
        clean[col] = clean[col].round().astype(int)
    return clean.reset_index(drop=True), {
        "raw_rows": int(len(df)),
        "source_row_start_1based": int(start + 2),
        "source_row_end_1based": int(end + 2),
        "segment_rows": int(end - start + 1),
    }


def rms(values):
    values = np.asarray(values, dtype=float)
    return float(np.sqrt(np.mean(values**2)))


def metrics(clean: pd.DataFrame, run_name: str, source_info: dict):
    exp = clean[clean.phase.isin([1, 2, 3, 4, 5])]
    move = clean[clean.phase.isin([2, 4])]
    hold = clean[clean.phase == 3]
    done = clean[clean.phase == 6]
    dt = np.diff(clean.time_rel_s)
    return {
        "run": run_name,
        "clean_rows": int(len(clean)),
        "duration_s": float(clean.time_rel_s.iloc[-1]),
        "sample_rate_hz": float(1.0 / np.median(dt)),
        "sequence_gaps": int(np.sum(np.diff(clean.sample_seq) != 1)),
        "phase_complete": bool(set(range(1, 7)).issubset(set(clean.phase))),
        "reference_peak_mm": float(exp.reference_m.max() * 1000),
        "hold_left_mm": float(hold.pos_left_m.mean() * 1000),
        "hold_right_mm": float(hold.pos_right_m.mean() * 1000),
        "hold_mean_mm": float(hold.mean_pos_m.mean() * 1000),
        "hold_sync_mean_mm": float(hold.sync_error_mm.mean()),
        "tracking_rmse_left_mm": rms((exp.pos_left_m - exp.reference_m) * 1000),
        "tracking_rmse_right_mm": rms((exp.pos_right_m - exp.reference_m) * 1000),
        "sync_rms_mm": rms(exp.sync_error_mm),
        "sync_peak_abs_mm": float(exp.sync_error_mm.abs().max()),
        "peak_velocity_left_mps": float(move.vel_left_mps.abs().max()),
        "peak_velocity_right_mps": float(move.vel_right_mps.abs().max()),
        "peak_cmd_left_raw": float(move.cmd_left_raw.abs().max()),
        "peak_cmd_right_raw": float(move.cmd_right_raw.abs().max()),
        "peak_feedback_left_raw": float(move.feedback_current_left_raw.abs().max()),
        "peak_feedback_right_raw": float(move.feedback_current_right_raw.abs().max()),
        "saturation_rows": int(((exp.sat_left != 0) | (exp.sat_right != 0)).sum()),
        "fault_rows": int((clean.fault_flags != 0).sum()),
        "battery_mean_V": float(clean.loc[clean.battery_V > 1, "battery_V"].mean()),
        "battery_min_V": float(clean.loc[clean.battery_V > 1, "battery_V"].min()),
        "temp_left_max_C": float(clean.temp_left_C.max()),
        "temp_right_max_C": float(clean.temp_right_C.max()),
        "can_age_left_max_during_experiment_ms": int(exp.can_age_left_ms.max()),
        "can_age_right_max_during_experiment_ms": int(exp.can_age_right_ms.max()),
        "final_left_mm": float(done.pos_left_m.tail(20).mean() * 1000),
        "final_right_mm": float(done.pos_right_m.tail(20).mean() * 1000),
        "final_sync_mm": float(done.sync_error_mm.tail(20).mean()),
        **source_info,
    }


def common_grid(runs):
    end = min(float(x.time_rel_s.max()) for x in runs)
    return np.arange(0.0, min(end, 14.0) + 1e-9, 0.013)


def interp_matrix(runs, grid, column):
    return np.vstack(
        [np.interp(grid, x.time_rel_s.to_numpy(float), x[column].to_numpy(float)) for x in runs]
    )


FONT_REGULAR = Path(r"C:\Windows\Fonts\arial.ttf")
FONT_BOLD = Path(r"C:\Windows\Fonts\arialbd.ttf")


def _font(size, bold=False):
    return ImageFont.truetype(str(FONT_BOLD if bold else FONT_REGULAR), size=size)


def _text(draw, xy, value, size=26, color="#222222", anchor="la", bold=False):
    draw.text(xy, value, font=_font(size, bold), fill=color, anchor=anchor)


def _axes(draw, box, xlim, ylim, xlabel, ylabel, xticks, yticks):
    left, top, right, bottom = box
    def px(x):
        return left + (x - xlim[0]) / (xlim[1] - xlim[0]) * (right - left)
    def py(y):
        return bottom - (y - ylim[0]) / (ylim[1] - ylim[0]) * (bottom - top)
    for x in xticks:
        xx = px(x)
        draw.line((xx, top, xx, bottom), fill="#D9D9D9", width=2)
        _text(draw, (xx, bottom + 20), f"{x:g}", 24, anchor="ma")
    for y in yticks:
        yy = py(y)
        draw.line((left, yy, right, yy), fill="#D9D9D9", width=2)
        _text(draw, (left - 18, yy), f"{y:g}", 24, anchor="rm")
    draw.line((left, top, left, bottom), fill="#333333", width=3)
    draw.line((left, bottom, right, bottom), fill="#333333", width=3)
    _text(draw, ((left + right) / 2, bottom + 72), xlabel, 28, anchor="ma")
    label = Image.new("RGBA", (430, 55), (255, 255, 255, 0))
    ld = ImageDraw.Draw(label)
    ld.text((215, 27), ylabel, font=_font(28), fill="#222222", anchor="mm")
    label = label.rotate(90, expand=True)
    draw._image.paste(label, (25, int((top + bottom - label.height) / 2)), label)
    return px, py


def _line(draw, px, py, xs, ys, color, width=5):
    points = [(px(float(x)), py(float(y))) for x, y in zip(xs, ys)]
    draw.line(points, fill=color, width=width, joint="curve")


def _legend(draw, x, y, items, columns=3):
    cell_w = 360
    for idx, (label, color, dashed) in enumerate(items):
        row, col = divmod(idx, columns)
        xx = x + col * cell_w
        yy = y + row * 42
        if dashed:
            for k in range(4):
                draw.line((xx + k * 28, yy, xx + k * 28 + 16, yy), fill=color, width=5)
        else:
            draw.line((xx, yy, xx + 100, yy), fill=color, width=5)
        _text(draw, (xx + 118, yy), label, 24, anchor="lm")


def save_figures(runs, metrics_list):
    grid = common_grid(runs)
    ref = interp_matrix(runs, grid, "reference_m") * 1000
    left = interp_matrix(runs, grid, "pos_left_m") * 1000
    right = interp_matrix(runs, grid, "pos_right_m") * 1000
    img = Image.new("RGB", (2100, 1080), "white")
    draw = ImageDraw.Draw(img)
    draw._image = img
    px, py = _axes(draw, (220, 90, 2020, 860), (0, 14), (-3, 54), "Time (s)", "Position (mm)", range(0, 15, 2), [0, 10, 20, 30, 40, 50])
    for matrix, color in [(left, "#1F77B4"), (right, "#D97706")]:
        mean = matrix.mean(axis=0)
        std = matrix.std(axis=0, ddof=1)
        overlay = Image.new("RGBA", img.size, (255, 255, 255, 0))
        od = ImageDraw.Draw(overlay)
        polygon = [(px(x), py(y)) for x, y in zip(grid, mean - std)] + [(px(x), py(y)) for x, y in zip(grid[::-1], (mean + std)[::-1])]
        od.polygon(polygon, fill=color + "30")
        img.paste(overlay, (0, 0), overlay)
        draw = ImageDraw.Draw(img)
        draw._image = img
        _line(draw, px, py, grid, mean, color, 5)
    points = [(px(float(x)), py(float(y))) for x, y in zip(grid, ref.mean(axis=0))]
    for i in range(0, len(points) - 1, 6):
        draw.line(points[i : min(i + 4, len(points))], fill="#111111", width=5)
    _legend(draw, 850, 35, [("Reference", "#111111", True), ("Left mean", "#1F77B4", False), ("Right mean", "#D97706", False)], 3)
    img.save(FIG_DIR / "Figure_1_Position_tracking.png", dpi=(300, 300))

    sync = interp_matrix(runs, grid, "sync_error_mm")
    img = Image.new("RGB", (2100, 1000), "white")
    draw = ImageDraw.Draw(img)
    draw._image = img
    px, py = _axes(draw, (220, 90, 2020, 790), (0, 14), (-0.8, 0.8), "Time (s)", "Synchronization error (mm)", range(0, 15, 2), [-0.8, -0.4, 0, 0.4, 0.8])
    colors = ["#93C5FD", "#60A5FA", "#3B82F6", "#2563EB", "#1D4ED8"]
    for series, color in zip(sync, colors):
        _line(draw, px, py, grid, series, color, 3)
    _line(draw, px, py, grid, sync.mean(axis=0), "#B91C1C", 5)
    _legend(draw, 520, 25, [(f"Run {i}", colors[i - 1], False) for i in range(1, 6)] + [("Mean", "#B91C1C", False)], 3)
    img.save(FIG_DIR / "Figure_2_Synchronization_error.png", dpi=(300, 300))

    cmd_l = interp_matrix(runs, grid, "cmd_left_raw")
    cmd_r = interp_matrix(runs, grid, "cmd_right_raw")
    fb_l = interp_matrix(runs, grid, "feedback_current_left_raw")
    fb_r = interp_matrix(runs, grid, "feedback_current_right_raw")
    img = Image.new("RGB", (2100, 1450), "white")
    draw = ImageDraw.Draw(img)
    draw._image = img
    panels = [((220, 90, 2020, 620), cmd_l, fb_l, "Left", "#1F77B4"), ((220, 760, 2020, 1290), cmd_r, fb_r, "Right", "#D97706")]
    for box, cmd, fb, side, color in panels:
        px, py = _axes(draw, box, (0, 14), (-2100, 2100), "Time (s)", "Current raw", range(0, 15, 2), [-2000, -1000, 0, 1000, 2000])
        _line(draw, px, py, grid, cmd.mean(axis=0), color, 5)
        _line(draw, px, py, grid, fb.mean(axis=0), "#4B5563", 3)
        _text(draw, (260, box[1] + 30), side, 28, bold=True)
        _legend(draw, 1160, box[1] + 25, [("Command mean", color, False), ("Feedback mean", "#4B5563", False)], 2)
    img.save(FIG_DIR / "Figure_3_Current_response.png", dpi=(300, 300))

    labels = [f"Run {i}" for i in range(1, 6)]
    left_rmse = [m["tracking_rmse_left_mm"] for m in metrics_list]
    right_rmse = [m["tracking_rmse_right_mm"] for m in metrics_list]
    sync_rms = [m["sync_rms_mm"] for m in metrics_list]
    img = Image.new("RGB", (2100, 1000), "white")
    draw = ImageDraw.Draw(img)
    draw._image = img
    px, py = _axes(draw, (220, 90, 2020, 790), (-0.5, 4.5), (0, 0.62), "Run", "Error (mm)", [], [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6])
    group_width = 0.72
    bar_width = group_width / 3
    series = [(left_rmse, "#1F77B4", "Left tracking RMSE"), (right_rmse, "#D97706", "Right tracking RMSE"), (sync_rms, "#64748B", "Sync RMS")]
    for sidx, (values, color, _) in enumerate(series):
        for ridx, value in enumerate(values):
            x0 = ridx - group_width / 2 + sidx * bar_width
            x1 = x0 + bar_width * 0.9
            draw.rectangle((px(x0), py(value), px(x1), py(0)), fill=color)
    for ridx, label in enumerate(labels):
        _text(draw, (px(ridx), 830), label, 24, anchor="ma")
    _legend(draw, 550, 35, [(label, color, False) for _, color, label in series], 3)
    img.save(FIG_DIR / "Figure_4_Repeatability_summary.png", dpi=(300, 300))


def main():
    CLEAN_DIR.mkdir(parents=True, exist_ok=True)
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    SUMMARY_DIR.mkdir(parents=True, exist_ok=True)
    runs = []
    metrics_list = []
    for idx, path in enumerate(sorted(RAW_DIR.glob("E1_noload_run*.csv")), 1):
        clean, source_info = extract_latest_complete(path)
        run_name = f"Run{idx:02d}"
        clean_path = CLEAN_DIR / f"E1_noload_run{idx:02d}_clean.csv"
        clean.to_csv(clean_path, index=False, encoding="utf-8-sig", float_format="%.6f")
        runs.append(clean)
        metrics_list.append(metrics(clean, run_name, source_info))

    numeric_keys = [
        "sample_rate_hz", "hold_mean_mm", "tracking_rmse_left_mm",
        "tracking_rmse_right_mm", "sync_rms_mm", "sync_peak_abs_mm",
        "peak_velocity_left_mps", "peak_velocity_right_mps",
        "battery_mean_V", "battery_min_V", "temp_left_max_C", "temp_right_max_C",
        "final_left_mm", "final_right_mm", "final_sync_mm",
    ]
    group = {}
    for key in numeric_keys:
        values = np.array([m[key] for m in metrics_list], dtype=float)
        group[key] = {
            "mean": float(values.mean()),
            "std": float(values.std(ddof=1)),
            "min": float(values.min()),
            "max": float(values.max()),
        }
    group["all_runs_valid"] = bool(all(
        m["phase_complete"] and m["sequence_gaps"] == 0 and m["fault_rows"] == 0
        and m["saturation_rows"] == 0 for m in metrics_list
    ))
    group["overall_sync_peak_abs_mm"] = float(max(m["sync_peak_abs_mm"] for m in metrics_list))
    group["overall_final_residual_abs_mm"] = float(max(
        max(abs(m["final_left_mm"]), abs(m["final_right_mm"])) for m in metrics_list
    ))
    summary = {
        "processing_method": {
            "raw_files": 5,
            "raw_rows_per_file": 50000,
            "selection": "Latest stable contiguous segment containing phases 1 through 6",
            "crop": "First phase-1 sample through 2 s after first phase-6 sample",
            "time_origin": "First phase-1 sample",
            "interpolation": "None in cleaned CSV; 13 ms common grid only for group figures",
        },
        "runs": metrics_list,
        "group": group,
    }
    (SUMMARY_DIR / "experiment1_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    save_figures(runs, metrics_list)
    print(json.dumps({"clean_files": len(runs), "all_runs_valid": group["all_runs_valid"], "group": group}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
