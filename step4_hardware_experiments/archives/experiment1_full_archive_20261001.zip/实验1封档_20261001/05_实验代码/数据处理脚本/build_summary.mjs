import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const summary = JSON.parse(await fs.readFile(path.join(ROOT, "03_统计汇总", "experiment1_summary.json"), "utf8"));
const outPath = path.join(ROOT, "03_统计汇总", "实验1统计汇总.xlsx");
const qaPath = path.join(ROOT, "03_统计汇总", "_qa_summary.png");
const font = "Microsoft YaHei";
const navy = "#17365D";
const blue = "#D9EAF7";
const pale = "#EEF5FA";
const green = "#E2F0D9";
const border = "#B8C4CE";

function parseCsv(text) {
  const rows = text.trim().split(/\r?\n/).map(line => line.split(","));
  const headers = rows[0];
  const data = rows.slice(1).map(row => row.map((v, i) => i === 0 ? Number(v) : Number(v)));
  return { headers, data };
}

function styleHeader(range) {
  range.format.fill = navy;
  range.format.font = { bold: true, color: "#FFFFFF", name: font, size: 10 };
  range.format.verticalAlignment = "center";
  range.format.horizontalAlignment = "center";
  range.format.wrapText = true;
  range.format.borders = { preset: "all", style: "thin", color: border };
}

function styleTable(range) {
  range.format.font = { name: font, size: 10, color: "#1F2937" };
  range.format.borders = { preset: "all", style: "thin", color: border };
  range.format.verticalAlignment = "center";
}

const wb = Workbook.create();
const ws = wb.worksheets.add("Summary");
const dict = wb.worksheets.add("Channel Dictionary");
const clean = wb.worksheets.add("Clean Data");

// Summary
ws.showGridLines = false;
ws.tabColor = navy;
ws.mergeCells("A1:H2");
ws.getRange("A1").values = [["实验1：空载对称低速往返基线——统计汇总"]];
ws.getRange("A1:H2").format.fill = navy;
ws.getRange("A1:H2").format.font = { name: font, bold: true, color: "#FFFFFF", size: 18 };
ws.getRange("A1:H2").format.horizontalAlignment = "center";
ws.getRange("A1:H2").format.verticalAlignment = "center";
ws.getRange("A4:B9").values = [
  ["项目", "结果"],
  ["有效运行", "5 / 5（全部有效）"],
  ["试验行程", "50 mm，空载、双电机对称往返"],
  ["控制周期", "1 ms"],
  ["实际记录频率", `${summary.group.sample_rate_hz.mean.toFixed(3)} Hz（约13 ms/点）`],
  ["数据处理", "每个原始文件取最后一个完整稳定的 phase 1–6 段；原始数据未修改"],
];
styleHeader(ws.getRange("A4:B4"));
styleTable(ws.getRange("A5:B9"));
ws.getRange("A10:H10").merge();
ws.getRange("A10").values = [["逐次试验关键指标"]];
ws.getRange("A10:H10").format.fill = blue;
ws.getRange("A10:H10").format.font = { name: font, bold: true, color: navy, size: 12 };

const runHeaders = ["Run", "保持均值/mm", "左RMSE/mm", "右RMSE/mm", "同步RMS/mm", "同步峰值/mm", "最低电压/V", "判定"];
const runRows = summary.runs.map(r => [
  r.run, r.hold_mean_mm, r.tracking_rmse_left_mm, r.tracking_rmse_right_mm,
  r.sync_rms_mm, r.sync_peak_abs_mm, r.battery_min_V,
  (r.phase_complete && r.sequence_gaps === 0 && r.fault_rows === 0 && r.saturation_rows === 0) ? "有效" : "复核"
]);
ws.getRange("A11:H16").values = [runHeaders, ...runRows];
styleHeader(ws.getRange("A11:H11"));
styleTable(ws.getRange("A12:H16"));
ws.getRange("B12:G16").format.numberFormat = "0.0000";
ws.getRange("H12:H16").format.fill = green;
ws.getRange("H12:H16").format.font = { name: font, bold: true, color: "#375623", size: 10 };

ws.getRange("A18:C18").values = [["组统计指标", "均值", "标准差"]];
styleHeader(ws.getRange("A18:C18"));
const groupLabels = ["保持位置/mm", "左侧跟踪RMSE/mm", "右侧跟踪RMSE/mm", "同步RMS/mm", "峰值速度左/m·s⁻¹", "峰值速度右/m·s⁻¹", "平均电池电压/V"];
ws.getRange("A19:A25").values = groupLabels.map(x => [x]);
ws.getRange("B19:C25").formulas = [
  ["=AVERAGE(B12:B16)", "=STDEV.S(B12:B16)"],
  ["=AVERAGE(C12:C16)", "=STDEV.S(C12:C16)"],
  ["=AVERAGE(D12:D16)", "=STDEV.S(D12:D16)"],
  ["=AVERAGE(E12:E16)", "=STDEV.S(E12:E16)"],
  [`=${summary.group.peak_velocity_left_mps.mean}`, `=${summary.group.peak_velocity_left_mps.std}`],
  [`=${summary.group.peak_velocity_right_mps.mean}`, `=${summary.group.peak_velocity_right_mps.std}`],
  [`=${summary.group.battery_mean_V.mean}`, `=${summary.group.battery_mean_V.std}`],
];
styleTable(ws.getRange("A19:C25"));
ws.getRange("B19:C25").format.numberFormat = "0.0000";

ws.getRange("A27:H27").merge();
ws.getRange("A27").values = [["结论：5 次试验均无故障、无饱和、无序号丢失；最大同步误差 0.7206 mm，最终残余位移不超过 0.0071 mm。"]];
ws.getRange("A27:H27").format.fill = green;
ws.getRange("A27:H27").format.font = { name: font, bold: true, color: "#375623", size: 11 };
ws.getRange("A27:H27").format.wrapText = true;
ws.getRange("A27:H27").format.rowHeight = 34;

ws.getRange("J10:M16").values = [
  ["Run", "左跟踪RMSE", "右跟踪RMSE", "同步RMS"],
  ...summary.runs.map(r => [r.run, r.tracking_rmse_left_mm, r.tracking_rmse_right_mm, r.sync_rms_mm]),
];
const chart = ws.charts.add("bar", ws.getRange("J10:M15"));
chart.setPosition("J1", "Q16");
chart.title = "五次试验误差指标对比";
chart.titleTextStyle.fontSize = 12;
chart.titleTextStyle.typeface = font;
chart.legend = { position: "top", textStyle: { typeface: font } };
chart.xAxis = { axisType: "textAxis", textStyle: { typeface: font, fontSize: 9 } };
chart.yAxis = { numberFormatCode: "0.00", numberFormatSourceLinked: false, textStyle: { typeface: font, fontSize: 9 } };
chart.xAxis.title.text = "运行编号";
chart.yAxis.title.text = "误差 / mm";

ws.getRange("A1:H30").format.font.name = font;
ws.getRange("A:A").format.columnWidth = 25;
ws.getRange("B:G").format.columnWidth = 15;
ws.getRange("H:H").format.columnWidth = 12;
ws.getRange("B:B").format.columnWidth = 46;
ws.freezePanes.freezeRows(3);

// Channel dictionary
dict.showGridLines = false;
dict.tabColor = "#5B9BD5";
const channelRows = [
  ["字段", "VOFA通道", "单位", "含义"],
  ["time_rel_s", "—", "s", "清洗后相对时间，phase 1 首点为0"],
  ["uptime_s", "I0", "s", "控制器运行时间"],
  ["sample_seq", "I1", "count", "发送样本序号"],
  ["phase", "I2", "—", "实验阶段1–6"],
  ["reference_m", "I3", "m", "参考位置"],
  ["pos_left_m", "I4", "m", "左电机位移"],
  ["pos_right_m", "I5", "m", "右电机位移"],
  ["mean_pos_m", "I6", "m", "两侧平均位移"],
  ["sync_error_mm", "I7", "mm", "左右同步误差"],
  ["vel_left_mps", "I8", "m/s", "左侧线速度"],
  ["vel_right_mps", "I9", "m/s", "右侧线速度"],
  ["cmd_left_raw", "I10", "raw", "左侧电流指令原始值"],
  ["cmd_right_raw", "I11", "raw", "右侧电流指令原始值"],
  ["feedback_current_left_raw", "I12", "raw", "左侧反馈电流原始值"],
  ["feedback_current_right_raw", "I13", "raw", "右侧反馈电流原始值"],
  ["sat_left", "I14", "flag", "左侧饱和标志"],
  ["sat_right", "I15", "flag", "右侧饱和标志"],
  ["temp_left_C", "I16", "°C", "左侧温度"],
  ["temp_right_C", "I17", "°C", "右侧温度"],
  ["battery_V", "I18", "V", "电池电压"],
  ["can_age_left_ms", "I19", "ms", "左侧CAN数据年龄"],
  ["can_age_right_ms", "I20", "ms", "右侧CAN数据年龄"],
  ["fault_flags", "I21", "flag", "故障标志"],
];
dict.getRange(`A1:D${channelRows.length}`).values = channelRows;
styleHeader(dict.getRange("A1:D1"));
styleTable(dict.getRange(`A2:D${channelRows.length}`));
dict.getRange("A:A").format.columnWidth = 31;
dict.getRange("B:B").format.columnWidth = 14;
dict.getRange("C:C").format.columnWidth = 13;
dict.getRange("D:D").format.columnWidth = 48;
dict.freezePanes.freezeRows(1);

// Consolidated clean data
clean.showGridLines = false;
clean.tabColor = "#A5A5A5";
let cleanHeaders = null;
const combined = [];
for (let i = 1; i <= 5; i++) {
  const name = `E1_noload_run0${i}_clean.csv`;
  const parsed = parseCsv(await fs.readFile(path.join(ROOT, "02_处理后数据", name), "utf8"));
  cleanHeaders ??= parsed.headers;
  for (const row of parsed.data) combined.push([`Run0${i}`, ...row]);
}
const allHeaders = ["run", ...cleanHeaders];
clean.getRangeByIndexes(0, 0, 1, allHeaders.length).values = [allHeaders];
clean.getRangeByIndexes(1, 0, combined.length, allHeaders.length).values = combined;
styleHeader(clean.getRangeByIndexes(0, 0, 1, allHeaders.length));
clean.getRangeByIndexes(1, 0, combined.length, allHeaders.length).format.font = { name: "Arial", size: 9, color: "#1F2937" };
clean.getRangeByIndexes(1, 0, combined.length, allHeaders.length).format.borders = { preset: "inside", style: "thin", color: "#E5E7EB" };
clean.getRangeByIndexes(1, 1, combined.length, allHeaders.length - 1).format.numberFormat = "0.000000";
clean.getRange("A:A").format.columnWidth = 10;
clean.getRangeByIndexes(0, 1, 1, allHeaders.length - 1).format.columnWidth = 16;
clean.freezePanes.freezeRows(1);
clean.freezePanes.freezeColumns(1);

await wb.recalculate();
const check = await wb.inspect({ kind: "region", sheetId: "Summary", range: "A1:H27", maxChars: 8000, tableMaxRows: 30, tableMaxCols: 8 });
console.log(check.ndjson);
const errors = await wb.inspect({ kind: "match", searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A", options: { useRegex: true, maxResults: 100 }, maxChars: 5000 });
console.log(errors.ndjson);
const preview = await wb.render({ sheetName: "Summary", autoCrop: "all", scale: 1, format: "png" });
await fs.writeFile(qaPath, new Uint8Array(await preview.arrayBuffer()));
const output = await SpreadsheetFile.exportXlsx(wb);
await output.save(outPath);
console.log(JSON.stringify({ outPath, qaPath, cleanRows: combined.length }));
