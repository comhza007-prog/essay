from __future__ import annotations

import json
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


ROOT = Path(__file__).resolve().parent
SUMMARY = json.loads((ROOT / "03_统计汇总" / "experiment1_summary.json").read_text(encoding="utf-8"))
OUT_DIR = ROOT / "00_说明文档"
OUT_DIR.mkdir(parents=True, exist_ok=True)
OUT_PATH = OUT_DIR / "实验1数据处理与论文说明.docx"
FIG_DIR = ROOT / "04_论文图"

NAVY = "17365D"
BLUE = "D9EAF7"
PALE = "EEF5FA"
GREEN = "E2F0D9"
GRAY = "6B7280"


def set_cell_shading(cell, fill: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_border(cell, color="B8C4CE", size="4"):
    tc_pr = cell._tc.get_or_add_tcPr()
    borders = tc_pr.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tc_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = "w:" + edge
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), size)
        element.set(qn("w:color"), color)


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_cn_font(run, name="Microsoft YaHei", size=10.5, bold=None, color=None):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), name)
    run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run("第 ")
    set_cn_font(run, size=9, color=GRAY)
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = " PAGE "
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr_text)
    run._r.append(fld_char2)
    run2 = paragraph.add_run(" 页")
    set_cn_font(run2, size=9, color=GRAY)


def add_title(doc, text, level=1):
    p = doc.add_paragraph()
    p.style = doc.styles[f"Heading {level}"]
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    set_cn_font(r, size=16 if level == 1 else 13, bold=True, color=NAVY)
    return p


def add_para(doc, text="", bold_prefix=None):
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.35
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.first_line_indent = Cm(0.74)
    if bold_prefix and text.startswith(bold_prefix):
        r1 = p.add_run(bold_prefix)
        set_cn_font(r1, bold=True)
        r2 = p.add_run(text[len(bold_prefix):])
        set_cn_font(r2)
    else:
        r = p.add_run(text)
        set_cn_font(r)
    return p


def add_bullets(doc, items):
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        p.paragraph_format.left_indent = Cm(0.7)
        p.paragraph_format.space_after = Pt(3)
        r = p.add_run(item)
        set_cn_font(r, size=10.5)


def add_table(doc, headers, rows, widths=None, font_size=8.5):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    hdr = table.rows[0]
    set_repeat_table_header(hdr)
    for i, h in enumerate(headers):
        cell = hdr.cells[i]
        set_cell_shading(cell, NAVY)
        set_cell_border(cell)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(str(h))
        set_cn_font(r, size=font_size, bold=True, color="FFFFFF")
        if widths:
            cell.width = Cm(widths[i])
    for ridx, row in enumerate(rows):
        cells = table.add_row().cells
        for i, value in enumerate(row):
            cell = cells[i]
            set_cell_border(cell)
            if ridx % 2 == 1:
                set_cell_shading(cell, PALE)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if i > 0 else WD_ALIGN_PARAGRAPH.LEFT
            r = p.add_run(str(value))
            set_cn_font(r, size=font_size)
            if widths:
                cell.width = Cm(widths[i])
    doc.add_paragraph().paragraph_format.space_after = Pt(1)
    return table


def add_figure(doc, filename, caption, width_cm=16.5):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(3)
    p.add_run().add_picture(str(FIG_DIR / filename), width=Cm(width_cm))
    cp = doc.add_paragraph()
    cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cp.paragraph_format.keep_with_next = False
    cp.paragraph_format.space_after = Pt(8)
    r = cp.add_run(caption)
    set_cn_font(r, size=9.5, bold=True, color="374151")


doc = Document()
section = doc.sections[0]
section.page_width = Cm(21.0)
section.page_height = Cm(29.7)
section.top_margin = Cm(1.8)
section.bottom_margin = Cm(1.7)
section.left_margin = Cm(2.0)
section.right_margin = Cm(2.0)

styles = doc.styles
styles["Normal"].font.name = "Microsoft YaHei"
styles["Normal"]._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
styles["Normal"].font.size = Pt(10.5)
for style_name in ("Heading 1", "Heading 2"):
    styles[style_name].font.name = "Microsoft YaHei"
    styles[style_name]._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")

for sec in doc.sections:
    hp = sec.header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    hr = hp.add_run("实验1｜空载对称低速往返基线")
    set_cn_font(hr, size=8.5, color=GRAY)
    add_page_number(sec.footer.paragraphs[0])

# Cover
p = doc.add_paragraph()
p.paragraph_format.space_before = Pt(80)
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run("实验1数据处理与论文说明")
set_cn_font(r, size=24, bold=True, color=NAVY)
p2 = doc.add_paragraph()
p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p2.add_run("空载对称低速往返基线｜五次重复试验")
set_cn_font(r, size=15, bold=True, color="4F81BD")

doc.add_paragraph()
cover_rows = [
    ["试验状态", "通过（5/5 次有效）"],
    ["处理日期", "2026-10-01"],
    ["正式数据", "Run01–Run05，共 5 次"],
    ["控制周期", "1 ms"],
    ["实际记录频率", "76.923 Hz（约 13 ms/点）"],
    ["归档内容", "原始数据、清洗数据、统计表、论文图、实验代码"],
]
add_table(doc, ["项目", "内容"], cover_rows, widths=[4.0, 11.5], font_size=10.5)

p = doc.add_paragraph()
p.paragraph_format.space_before = Pt(20)
p.paragraph_format.left_indent = Cm(1.2)
p.paragraph_format.right_indent = Cm(1.2)
p.paragraph_format.space_after = Pt(8)
r = p.add_run(
    "结论摘要：五次运行均完成 phase 1–6，未出现序号丢失、故障或电流饱和。"
    "50 mm 保持位置均值为 50.0255±0.0133 mm；左右跟踪 RMSE 分别为 "
    "0.5160±0.0008 mm 和 0.4974±0.0020 mm；同步 RMS 为 0.1522±0.0043 mm，"
    "最大同步误差为 0.7206 mm。"
)
set_cn_font(r, size=11.5, bold=True, color="375623")
set_cell = None

doc.add_page_break()

# Methods and cleaning
add_title(doc, "1　实验目的与实施条件")
add_para(doc, "本实验用于建立双电机系统在空载、对称、低速往返工况下的位置跟踪与同步控制基线，为后续负载、扰动和参数对比实验提供参照。每次上电复位后只执行一次自动序列，避免连续运行历史混入同一次正式结果。")
add_table(doc, ["参数", "设定值", "说明"], [
    ["目标行程", "0.050 m", "两侧同向、对称往返"],
    ["速度上限", "±300 rpm", "保守首轮设置"],
    ["电流指令限幅", "±2000 raw", "未换算为物理电流"],
    ["有效驱动半径", "0.030 m", "论文定稿前需实测确认"],
    ["减速比 / 编码器", "19 / 8192 CPR", "用于位移换算"],
    ["控制周期", "1 ms", "固件任务周期"],
    ["CAN超时 / 同步保护", "50 ms / 5 mm", "软件保护阈值"],
    ["温度 / 行程保护", "80 °C / 70 mm", "软件保护阈值"],
], widths=[4.0, 4.0, 7.5], font_size=9)

add_title(doc, "2　单次运行时序", level=2)
add_bullets(doc, [
    "复位后等待 1.5 s，并确认两侧反馈帧有效；随后以当前位置为零点。",
    "3 s 解锁等待期内电流指令保持为零。",
    "正式 12 s 序列：0–2 s 零位保持；2–5 s 五次多项式前进；5–7 s 在 50 mm 保持；7–10 s 五次多项式返回；10–12 s 零位保持。",
    "序列结束后电流指令永久置零；下一次正式运行需重新复位。",
])

add_title(doc, "3　原始数据识别与清洗规则", level=2)
add_para(doc, "VOFA 导出的 5 个 CSV 均包含 50,000 行固定长度历史缓冲，后导出的文件会包含前次运行片段。因此，整文件不能直接视为一组独立试验。处理程序在每个文件中定位最后一个连续、稳定且完整包含 phase 1–6 的片段，取 phase 1 首点至 phase 6 首点后 2 s，并把 phase 1 首点重新定义为相对时间 0。")
add_bullets(doc, [
    "清洗后的 CSV 不进行插值，保留实际采样点。",
    "组图仅为比较方便，使用 13 ms 公共时间网格进行绘图插值；统计指标使用清洗后的实际样本计算。",
    "原始 CSV 原样复制进封档，未覆盖、未重排、未修改。",
    "实际日志频率为 76.923 Hz，而不是名义约 100 Hz；论文中应报告实测频率。",
])

# Dictionary
add_title(doc, "4　VOFA通道与清洗字段定义")
channels = [
    ("time_rel_s", "—", "s", "相对时间，phase 1 首点为0"),
    ("uptime_s", "I0", "s", "系统运行时间"),
    ("sample_seq", "I1", "count", "发送样本序号"),
    ("phase", "I2", "—", "试验阶段1–6"),
    ("reference_m", "I3", "m", "参考位置"),
    ("pos_left_m", "I4", "m", "左侧位置"),
    ("pos_right_m", "I5", "m", "右侧位置"),
    ("mean_pos_m", "I6", "m", "两侧平均位置"),
    ("sync_error_mm", "I7", "mm", "左右同步误差"),
    ("vel_left_mps", "I8", "m/s", "左侧线速度"),
    ("vel_right_mps", "I9", "m/s", "右侧线速度"),
    ("cmd_left_raw", "I10", "raw", "左侧电流指令"),
    ("cmd_right_raw", "I11", "raw", "右侧电流指令"),
    ("feedback_current_left_raw", "I12", "raw", "左侧反馈电流"),
    ("feedback_current_right_raw", "I13", "raw", "右侧反馈电流"),
    ("sat_left / sat_right", "I14 / I15", "flag", "两侧饱和标志"),
    ("temp_left_C / temp_right_C", "I16 / I17", "°C", "两侧温度"),
    ("battery_V", "I18", "V", "电池电压"),
    ("can_age_left_ms / right", "I19 / I20", "ms", "两侧CAN数据年龄"),
    ("fault_flags", "I21", "flag", "故障位掩码"),
]
add_table(doc, ["清洗字段", "VOFA通道", "单位", "含义"], channels, widths=[5.3, 3.2, 2.0, 6.0], font_size=8.3)
add_para(doc, "故障位定义：1 为左侧 CAN 超时，2 为右侧 CAN 超时，4 为过温，8 为同步误差超限，16 为行程超限，32 为用户/调试中止。五次正式运行的 fault_flags 均为 0。")

doc.add_page_break()

# Results
add_title(doc, "5　试验结果与有效性判定")
accuracy_rows = []
condition_rows = []
for r in SUMMARY["runs"]:
    accuracy_rows.append([
        r["run"], f'{r["hold_mean_mm"]:.4f}', f'{r["tracking_rmse_left_mm"]:.4f}',
        f'{r["tracking_rmse_right_mm"]:.4f}', f'{r["sync_rms_mm"]:.4f}', f'{r["sync_peak_abs_mm"]:.4f}'
    ])
    condition_rows.append([
        r["run"], f'{r["peak_velocity_left_mps"]:.4f}', f'{r["peak_velocity_right_mps"]:.4f}',
        f'{r["battery_mean_V"]:.3f}', f'{r["battery_min_V"]:.3f}',
        f'{r["temp_left_max_C"]:.0f}/{r["temp_right_max_C"]:.0f}', "0/0", "有效"
    ])
add_title(doc, "5.1　位置跟踪与同步指标", level=2)
add_table(doc, ["运行", "保持均值/mm", "左RMSE/mm", "右RMSE/mm", "同步RMS/mm", "同步峰值/mm"], accuracy_rows,
          widths=[2.0, 3.0, 2.7, 2.7, 2.7, 2.7], font_size=8.3)
add_para(doc, "组统计结果：50 mm 保持位置均值为 50.0255±0.0133 mm；左侧跟踪 RMSE 为 0.5160±0.0008 mm，右侧为 0.4974±0.0020 mm；同步 RMS 为 0.1522±0.0043 mm。五次运行中的最大同步误差绝对值为 0.7206 mm。")

add_title(doc, "5.2　运行条件与数据质量", level=2)
add_table(doc, ["运行", "左峰速/m·s⁻¹", "右峰速/m·s⁻¹", "均压/V", "最低/V", "最高温/°C L/R", "故障/饱和", "判定"], condition_rows,
          widths=[1.6, 2.2, 2.2, 1.8, 1.8, 2.7, 2.3, 1.7], font_size=7.7)
add_bullets(doc, [
    "五次运行均完成 phase 1–6，样本序号无断点。",
    "故障行数与饱和行数均为 0。",
    "清洗窗口内两侧最高温度均为 23 °C；全组最低电池电压为 24.140 V。",
    "最终残余位移绝对值最大为 0.00705 mm。",
])

doc.add_page_break()

# Figures 1-2
add_title(doc, "6　论文用图")
add_figure(doc, "Figure_1_Position_tracking.png", "图1　五次试验平均位置跟踪曲线", width_cm=16.6)
add_figure(doc, "Figure_2_Synchronization_error.png", "图2　五次试验同步误差及组均值", width_cm=16.6)

doc.add_page_break()
add_figure(doc, "Figure_3_Current_response.png", "图3　左右侧电流指令与反馈响应（五次均值）", width_cm=15.5)
add_figure(doc, "Figure_4_Repeatability_summary.png", "图4　五次重复试验误差指标对比", width_cm=16.0)

doc.add_page_break()

# Paper-ready content and archive
add_title(doc, "7　可直接用于论文的表述")
add_title(doc, "7.1　实验方法（建议稿）", level=2)
add_para(doc, "为验证双电机同步控制系统在基础工况下的重复性与跟踪性能，开展空载对称低速往返实验。控制器以 1 ms 周期运行，两侧电机采用相同的五次多项式位置参考，在 50 mm 行程内完成前进、保持、返回和零位保持。每次复位仅执行一次 12 s 正式序列，共获得 5 次有效重复试验。VOFA 数据的实测记录频率为 76.923 Hz。针对导出文件包含固定长度累积历史缓冲的问题，从每个文件中提取最后一个完整包含 phase 1–6 的连续片段，并以 phase 1 首个样本作为相对时间零点。")

add_title(doc, "7.2　结果分析（建议稿）", level=2)
add_para(doc, "五次空载往返试验均完整执行，未出现通信故障、电流饱和或样本序号丢失。50 mm 保持阶段的平均位置为 50.0255±0.0133 mm；左右两侧位置跟踪均方根误差分别为 0.5160±0.0008 mm 和 0.4974±0.0020 mm。双侧同步误差的均方根值为 0.1522±0.0043 mm，五次试验中的最大同步误差绝对值为 0.7206 mm。返回零位后的最大残余位移为 0.00705 mm，说明系统在该空载低速工况下具有较好的同步性、重复性和回零性能。")

add_title(doc, "8　使用限制与后续论文注意事项")
add_bullets(doc, [
    "位移换算当前采用 30 mm 有效驱动半径。论文定稿前必须测量滑轮/卷筒的实际有效半径；如数值不同，应重新换算全部位移和速度指标。",
    "电流通道为驱动器 raw 值，尚未给出标定系数，因此正文中应写“电流指令/反馈原始值”，不得直接标注 A。",
    "日志实测频率为 76.923 Hz。控制周期 1 ms 与记录周期约 13 ms 属于不同概念，论文中应分别报告。",
    "本组为无负载基线，只能支持该工况下的结论，不应外推为额定负载性能。",
])

doc.add_page_break()
add_title(doc, "9　封档结构与复现说明")
archive_rows = [
    ["00_说明文档", "本报告及使用说明"],
    ["01_原始数据", "5 个原始 CSV，保持原样"],
    ["02_处理后数据", "5 个标准化 clean CSV"],
    ["03_统计汇总", "JSON 统计结果与 Excel 汇总"],
    ["04_论文图", "4 张 300 dpi 图"],
    ["05_实验代码", "源码快照、HEX、配置、编译日志"],
    ["封档清单_SHA256.txt", "文件完整性校验清单"],
]
add_table(doc, ["相对路径", "内容"], archive_rows, widths=[6.2, 9.3], font_size=9)
add_para(doc, "复现流程：使用 05_实验代码 中的固件快照重新编译或直接烧录 HEX；每次复位后单独记录 VOFA 22 通道数据；运行 process_exp1.py 可重新生成清洗 CSV、统计 JSON 和论文图。归档前的 Keil 构建结果为 0 Error(s)、0 Warning(s)。")

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.space_before = Pt(14)
r = p.add_run("封档结论：实验1数据与代码检查通过，可用于后续论文整理。")
set_cn_font(r, size=12, bold=True, color="375623")

doc.save(OUT_PATH)
print(OUT_PATH)
