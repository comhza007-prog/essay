#ifndef MOTOR_TASK_H
#define MOTOR_TASK_H

#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "CAN_receive.h"
#include "motor.h"

typedef enum
{
    EXP1_PHASE_ARMING = 0,
    EXP1_PHASE_HOLD_START = 1,
    EXP1_PHASE_FORWARD = 2,
    EXP1_PHASE_HOLD_END = 3,
    EXP1_PHASE_RETURN = 4,
    EXP1_PHASE_HOLD_FINISH = 5,
    EXP1_PHASE_DONE = 6,
    EXP1_PHASE_FAULT = 7
} exp1_phase_t;

typedef struct
{
    volatile uint32_t elapsed_ms;
    volatile uint8_t phase;
    volatile uint8_t running;
    volatile uint8_t finished;
    volatile uint8_t fault_flags;
    volatile float reference_m;
    volatile int16_t cmd_left;
    volatile int16_t cmd_right;
    volatile uint8_t sat_left;
    volatile uint8_t sat_right;
} experiment1_state_t;

extern volatile uint8_t g_exp1_abort;
extern experiment1_state_t g_exp1;

void motor_task(void const *argument);

#endif
