#include "vofa_task.h"
#include "motor_task.h"
#include "motor.h"
#include "CAN_receive.h"

extern motor_measure_t motor_3508[2];
extern float Batvalt;

static float send_message[VOFA_CHANNEL_COUNT];
static Vofa_t Vofa;

static uint32_t age_ms(uint8_t index, uint32_t now_ms)
{
    if (motor_3508[index].rx_count == 0U)
    {
        /* Keep the VOFA auto-scale usable while CAN is disconnected. */
        return 1000U;
    }
    return now_ms - motor_3508[index].last_rx_ms;
}

void vofa_task(void const *argument)
{
    uint32_t now_ms;
    uint32_t sample_seq = 0U;
    float pos_left_m;
    float pos_right_m;
    float vel_left_mps;
    float vel_right_mps;

    (void)argument;
    Vofa_tail_init();

    for (;;)
    {
        now_ms = HAL_GetTick();
        pos_left_m = ((float)motor_3508[0].total_ecd - chassis_ang_init[0]) *
                     EXP1_METERS_PER_MOTOR_COUNT;
        pos_right_m = -((float)motor_3508[1].total_ecd - chassis_ang_init[1]) *
                      EXP1_METERS_PER_MOTOR_COUNT;
        vel_left_mps = ((float)motor_3508[0].speed_rpm / 60.0f) *
                       (2.0f * EXP1_PI * EXP1_DRIVE_RADIUS_M / EXP1_GEAR_RATIO);
        vel_right_mps = -((float)motor_3508[1].speed_rpm / 60.0f) *
                        (2.0f * EXP1_PI * EXP1_DRIVE_RADIUS_M / EXP1_GEAR_RATIO);

        /*
         * VOFA+ JustFloat channel order (100 Hz):
         *  0 time_s,       1 sample_seq,    2 phase,          3 reference_m,
         *  4 pos_left_m,   5 pos_right_m,   6 mean_pos_m,     7 sync_error_mm,
         *  8 vel_left_mps, 9 vel_right_mps, 10 cmd_left,      11 cmd_right,
         * 12 fb_current_L, 13 fb_current_R, 14 sat_left,       15 sat_right,
         * 16 temp_left_C,  17 temp_right_C, 18 battery_V,      19 can_age_L_ms,
         * 20 can_age_R_ms, 21 fault_flags.
         */
        /* System uptime is an immediate heartbeat, even while motor CAN is absent. */
        send_message[0] = (float)now_ms * 0.001f;
        send_message[1] = (float)sample_seq++;
        send_message[2] = (float)g_exp1.phase;
        send_message[3] = g_exp1.reference_m;
        send_message[4] = pos_left_m;
        send_message[5] = pos_right_m;
        send_message[6] = 0.5f * (pos_left_m + pos_right_m);
        send_message[7] = (pos_left_m - pos_right_m) * 1000.0f;
        send_message[8] = vel_left_mps;
        send_message[9] = vel_right_mps;
        send_message[10] = (float)g_exp1.cmd_left;
        send_message[11] = (float)g_exp1.cmd_right;
        send_message[12] = (float)motor_3508[0].given_current;
        send_message[13] = (float)motor_3508[1].given_current;
        send_message[14] = (float)g_exp1.sat_left;
        send_message[15] = (float)g_exp1.sat_right;
        send_message[16] = (float)motor_3508[0].temperate;
        send_message[17] = (float)motor_3508[1].temperate;
        send_message[18] = Batvalt;
        send_message[19] = (float)age_ms(0U, now_ms);
        send_message[20] = (float)age_ms(1U, now_ms);
        send_message[21] = (float)g_exp1.fault_flags;

        Vofa_send_justfloat(send_message);
        (void)HAL_UART_Transmit(&huart6, Vofa.message, sizeof(Vofa.message), 20U);
        osDelay(2U);
    }
}

void Vofa_tail_init(void)
{
    Vofa.tail[0] = 0x00U;
    Vofa.tail[1] = 0x00U;
    Vofa.tail[2] = 0x80U;
    Vofa.tail[3] = 0x7FU;
}

void Float_to_Byte(float f, uint8_t byte[])
{
    FloatLongType value;
    value.float_data = f;

    byte[0] = (uint8_t)value.long_data;
    byte[1] = (uint8_t)(value.long_data >> 8);
    byte[2] = (uint8_t)(value.long_data >> 16);
    byte[3] = (uint8_t)(value.long_data >> 24);
}

void Vofa_send_justfloat(float *values)
{
    uint8_t channel_index;
    uint8_t byte_index;

    for (channel_index = 0U; channel_index < VOFA_CHANNEL_COUNT; channel_index++)
    {
        Float_to_Byte(values[channel_index], Vofa.temp);
        for (byte_index = 0U; byte_index < 4U; byte_index++)
        {
            Vofa.message[channel_index * 4U + byte_index] = Vofa.temp[byte_index];
        }
    }

    for (byte_index = 0U; byte_index < 4U; byte_index++)
    {
        Vofa.message[VOFA_CHANNEL_COUNT * 4U + byte_index] = Vofa.tail[byte_index];
    }
}
