#include "motor_task.h"

extern motor_measure_t motor_3508[2];

volatile uint8_t g_exp1_abort = 0U;
experiment1_state_t g_exp1;

#define EXP1_FAULT_CAN_LEFT       0x01U
#define EXP1_FAULT_CAN_RIGHT      0x02U
#define EXP1_FAULT_TEMPERATURE    0x04U
#define EXP1_FAULT_SYNCHRONISM    0x08U
#define EXP1_FAULT_TRAVEL         0x10U
#define EXP1_FAULT_USER_ABORT     0x20U

static float smoothstep5(float u)
{
    float u2;
    float u3;

    if (u <= 0.0f)
    {
        return 0.0f;
    }
    if (u >= 1.0f)
    {
        return 1.0f;
    }

    u2 = u * u;
    u3 = u2 * u;
    return u3 * (10.0f + u * (-15.0f + 6.0f * u));
}

static float trajectory_reference(uint32_t elapsed_ms, uint8_t *phase)
{
    uint32_t segment_ms;
    float u;

    if (elapsed_ms < EXP1_HOLD_START_MS)
    {
        *phase = EXP1_PHASE_HOLD_START;
        return 0.0f;
    }

    if (elapsed_ms < (EXP1_HOLD_START_MS + EXP1_FORWARD_MS))
    {
        *phase = EXP1_PHASE_FORWARD;
        segment_ms = elapsed_ms - EXP1_HOLD_START_MS;
        u = (float)segment_ms / (float)EXP1_FORWARD_MS;
        return EXP1_STROKE_M * smoothstep5(u);
    }

    if (elapsed_ms < (EXP1_HOLD_START_MS + EXP1_FORWARD_MS + EXP1_HOLD_END_MS))
    {
        *phase = EXP1_PHASE_HOLD_END;
        return EXP1_STROKE_M;
    }

    if (elapsed_ms < (EXP1_HOLD_START_MS + EXP1_FORWARD_MS +
                      EXP1_HOLD_END_MS + EXP1_RETURN_MS))
    {
        *phase = EXP1_PHASE_RETURN;
        segment_ms = elapsed_ms - (EXP1_HOLD_START_MS + EXP1_FORWARD_MS +
                                   EXP1_HOLD_END_MS);
        u = (float)segment_ms / (float)EXP1_RETURN_MS;
        return EXP1_STROKE_M * (1.0f - smoothstep5(u));
    }

    if (elapsed_ms < EXP1_TOTAL_MS)
    {
        *phase = EXP1_PHASE_HOLD_FINISH;
        return 0.0f;
    }

    *phase = EXP1_PHASE_DONE;
    return 0.0f;
}

static uint32_t can_age_ms(uint8_t index, uint32_t now_ms)
{
    if (motor_3508[index].rx_count == 0U)
    {
        return 0xFFFFFFFFU;
    }
    return now_ms - motor_3508[index].last_rx_ms;
}

static uint8_t protection_check(uint32_t now_ms)
{
    uint8_t fault = 0U;
    float pos_left_m;
    float pos_right_m;

    if (can_age_ms(0U, now_ms) > EXP1_CAN_TIMEOUT_MS)
    {
        fault |= EXP1_FAULT_CAN_LEFT;
    }
    if (can_age_ms(1U, now_ms) > EXP1_CAN_TIMEOUT_MS)
    {
        fault |= EXP1_FAULT_CAN_RIGHT;
    }
    if ((motor_3508[0].temperate >= EXP1_TEMPERATURE_LIMIT_C) ||
        (motor_3508[1].temperate >= EXP1_TEMPERATURE_LIMIT_C))
    {
        fault |= EXP1_FAULT_TEMPERATURE;
    }

    pos_left_m = ((float)motor_3508[0].total_ecd - chassis_ang_init[0]) *
                 EXP1_METERS_PER_MOTOR_COUNT;
    pos_right_m = -((float)motor_3508[1].total_ecd - chassis_ang_init[1]) *
                  EXP1_METERS_PER_MOTOR_COUNT;

    if (fabsf(pos_left_m - pos_right_m) > EXP1_SYNC_FAULT_M)
    {
        fault |= EXP1_FAULT_SYNCHRONISM;
    }
    if ((fabsf(pos_left_m) > EXP1_TRAVEL_FAULT_M) ||
        (fabsf(pos_right_m) > EXP1_TRAVEL_FAULT_M))
    {
        fault |= EXP1_FAULT_TRAVEL;
    }
    if (g_exp1_abort != 0U)
    {
        fault |= EXP1_FAULT_USER_ABORT;
    }

    return fault;
}

static int16_t current_command(float pid_output)
{
    if (pid_output > EXP1_CURRENT_LIMIT)
    {
        pid_output = EXP1_CURRENT_LIMIT;
    }
    else if (pid_output < -EXP1_CURRENT_LIMIT)
    {
        pid_output = -EXP1_CURRENT_LIMIT;
    }
    return (int16_t)pid_output;
}

static void command_zero(void)
{
    g_exp1.cmd_left = 0;
    g_exp1.cmd_right = 0;
    g_exp1.sat_left = 0U;
    g_exp1.sat_right = 0U;
    CAN_cmd_3508(0, 0);
}

void motor_task(void const *argument)
{
    uint32_t arm_start_ms;
    uint32_t feedback_wait_start_ms;
    uint32_t experiment_start_ms;
    uint32_t now_ms;
    uint8_t phase;
    uint8_t fault;
    float reference_m;

    (void)argument;
    g_exp1.phase = EXP1_PHASE_ARMING;
    command_zero();
    osDelay(1500U);

    feedback_wait_start_ms = HAL_GetTick();
    while ((motor_3508[0].rx_count == 0U) || (motor_3508[1].rx_count == 0U))
    {
        if ((HAL_GetTick() - feedback_wait_start_ms) >= 3000U)
        {
            if (motor_3508[0].rx_count == 0U)
            {
                g_exp1.fault_flags |= EXP1_FAULT_CAN_LEFT;
            }
            if (motor_3508[1].rx_count == 0U)
            {
                g_exp1.fault_flags |= EXP1_FAULT_CAN_RIGHT;
            }
            g_exp1.phase = EXP1_PHASE_FAULT;
            g_exp1.finished = 1U;
            for (;;)
            {
                command_zero();
                osDelay(1U);
            }
        }
        command_zero();
        osDelay(1U);
    }

    motor_init();
    arm_start_ms = HAL_GetTick();

    while ((HAL_GetTick() - arm_start_ms) < EXP1_ARM_DELAY_MS)
    {
        now_ms = HAL_GetTick();
        fault = protection_check(now_ms);
        if (fault != 0U)
        {
            g_exp1.fault_flags |= fault;
            g_exp1.phase = EXP1_PHASE_FAULT;
            g_exp1.finished = 1U;
            motor_stop_and_clear();
            for (;;)
            {
                command_zero();
                osDelay(1U);
            }
        }
        command_zero();
        osDelay(1U);
    }

#if EXP1_AUTORUN_ENABLE
    experiment_start_ms = HAL_GetTick();
    g_exp1.running = 1U;

    for (;;)
    {
        now_ms = HAL_GetTick();
        g_exp1.elapsed_ms = now_ms - experiment_start_ms;
        reference_m = trajectory_reference(g_exp1.elapsed_ms, &phase);
        g_exp1.reference_m = reference_m;
        g_exp1.phase = phase;

        fault = protection_check(now_ms);
        g_exp1.fault_flags |= fault;

        if (g_exp1.fault_flags != 0U)
        {
            g_exp1.running = 0U;
            g_exp1.finished = 1U;
            g_exp1.phase = EXP1_PHASE_FAULT;
            motor_stop_and_clear();
            command_zero();
        }
        else if (g_exp1.elapsed_ms >= EXP1_TOTAL_MS)
        {
            g_exp1.running = 0U;
            g_exp1.finished = 1U;
            g_exp1.phase = EXP1_PHASE_DONE;
            motor_stop_and_clear();
            command_zero();
        }
        else
        {
            motor_track_reference_m(reference_m);
            g_exp1.cmd_left = current_command(SPEED_PID[0].out);
            g_exp1.cmd_right = current_command(SPEED_PID[1].out);
            g_exp1.sat_left = (fabsf(SPEED_PID[0].out) >= (EXP1_CURRENT_LIMIT - 1.0f));
            g_exp1.sat_right = (fabsf(SPEED_PID[1].out) >= (EXP1_CURRENT_LIMIT - 1.0f));
            CAN_cmd_3508(g_exp1.cmd_left, g_exp1.cmd_right);
        }

        osDelay(1U);
    }
#else
    for (;;)
    {
        command_zero();
        osDelay(1U);
    }
#endif
}
