#include "BMS_task.h"

float Vrefdata = 0.f; //��ѹ�ο���׼
float Batvalt = 0.f;  //��ѹֵ
float MIN_VLT = 23.0f ;//��ѹ����ֵ

void BMS_task(void const * argument)
{

  for(;;)
  {
		HAL_ADC_Start(&hadc1);
		while(!HAL_ADC_PollForConversion(&hadc1,1));
		Vrefdata=1.21/HAL_ADC_GetValue(&hadc1);
		
		HAL_ADC_Start(&hadc3);
		while(!HAL_ADC_PollForConversion(&hadc3,1));
		Batvalt=HAL_ADC_GetValue(&hadc3)*Vrefdata*10.090909090909090909090909090909f;

    osDelay(10);
  }
  
}



