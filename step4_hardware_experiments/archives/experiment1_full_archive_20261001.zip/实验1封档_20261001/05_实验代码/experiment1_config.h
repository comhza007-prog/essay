#ifndef EXPERIMENT1_CONFIG_H
#define EXPERIMENT1_CONFIG_H

/*
 * Experiment 1: no-load, symmetric, low-speed, one-shot reciprocation.
 * Verify EXP1_DRIVE_RADIUS_M against the actual drive wheel/pulley effective
 * radius before using displacement values in the paper.
 */
#define EXP1_AUTORUN_ENABLE          1U
#define EXP1_ARM_DELAY_MS            3000U

#define EXP1_HOLD_START_MS           2000U
#define EXP1_FORWARD_MS              3000U
#define EXP1_HOLD_END_MS             2000U
#define EXP1_RETURN_MS               3000U
#define EXP1_HOLD_FINISH_MS          2000U
#define EXP1_TOTAL_MS                12000U

/* Conservative first-run settings. Increase only after the first run is safe. */
#define EXP1_STROKE_M                0.050f
#define EXP1_DRIVE_RADIUS_M          0.030f
#define EXP1_GEAR_RATIO              19.0f
#define EXP1_ENCODER_CPR             8192.0f
#define EXP1_SPEED_LIMIT_RPM         300.0f
#define EXP1_CURRENT_LIMIT           2000.0f
#define EXP1_CURRENT_I_LIMIT         500.0f

/* Software protection thresholds. A physical power-cut E-stop is still required. */
#define EXP1_CAN_TIMEOUT_MS          50U
#define EXP1_TEMPERATURE_LIMIT_C     80U
#define EXP1_SYNC_FAULT_M            0.005f
#define EXP1_TRAVEL_FAULT_M          0.070f

#define EXP1_PI                      3.14159265358979323846f
#define EXP1_METERS_PER_MOTOR_COUNT  \
    ((2.0f * EXP1_PI * EXP1_DRIVE_RADIUS_M) / (EXP1_GEAR_RATIO * EXP1_ENCODER_CPR))

#endif
